/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package comanders;

import java.util.Scanner;

/**
 *
 * @author Usuario
 */
public class COMANDERS {

    /**
     * @param args the command line arguments
     */
    @SuppressWarnings("empty-statement")
    public static void main(String[] args) {

        Scanner leer = new Scanner(System.in);

        String COMANDOG;

        System.err.println("RECUERDA UTILIZAR * ESTO SIMULA UN ESPACIO");

        System.out.println("");
        System.out.println("");

        System.out.println("MENU");


        System.out.println("-----------------------------------------------------------------------------------------------------------------------------------------------------");

        System.out.println("INTRODUCCION-----TRABALLO*NO*TERMINAL----CARACTERISTICAS----FORMAS*DE*AXUDA----ACTUALIZACION*DO*S.O--ACTUALIZACION*DO*SISTEMA*OPERATIVO--------------");

        System.out.println("ESTRUCTURA*DE*S.O-----COMANDOS*DE*XESTION*E*FLUXOVISUAL----REDIRECCIONAMIENTO----TUBERIA----ENLACES------COMPARACION*E*AGRUPACION*DE*ARQUIVOS--------");
        System.out.print("-------------------------------------------------------------------------------------------------------------------------------------------------------");

        System.out.println("");
        System.out.println("");
        System.out.println("");

        System.out.println("TECLEA UNA SECCION");

//            COMANDOG=leer.nextLine();
        do {

            COMANDOG = leer.next();

            switch (COMANDOG) {

////////////////    
//INTRODUCCION//
////////////////   
                case "INTRODUCCION": {

                    System.out.println("Interfaces:");
                    System.out.println("Gráfica (se se instalou unha interfaz gráfica (GNOME, KDE, XFCE, etc)");
                    System.out.println("Terminal (modo texto)");
                    System.out.println("Simulación de varias terminais, permitindo ter abertas varias sesións ó mesmo tempo do mesmo ou diferentes usuarios.");

                    break;

                }

////////////////////////////   
//TRABALLO NO TERMINAL//////
////////////////////////////
                case "TRABALLO*NO*TERMINAL": {

                    System.out.println("-Cambiar de consola pulsamos Alt+Fx (teclas de función)");
                    System.out.println("-En algunhas distribucións, podemos ter ata 24 consolas (ás 12 primeiras accedese mediante Alt dereito e ás 12 segundas mediante Alt esquerdo).");
                    System.out.println("Exemplo: para chegar a consola 16, prememos as teclas Alt dereito e F4.");
                    System.out.println("En Ubuntu existen seis consolas disponibles. Para acceder a cada unhaa delas empregase as combinacións Ctrl-Alt-F1 e Ctrl-Alt-F6.");
                    System.out.println("Para cambiar a unha consola desde o modo gráfico pulsamos Ctrl+Alt+Fx");
                    System.out.println("Se estamos executando dentro dun SO virtual, esta combinación de teclas pode non funcionar xa que está asignada a Vmware/VirtualBox como atallo de teclado.");
                    System.out.println("Coa tecla Alt Esquerda e mais os cursores podemos movernos circularmente polas consolas.");

                    break;

                }

///////////////////
//CARACTERISTICAS//
///////////////////   
                case "CARACTERISTICAS": {

                    System.out.println("Autocompletar:");
                    System.out.println(" ó teclear varios caracteres pode pulsarse a tecla TAB para completar un comando, nome de arquivo ou variable.");
                    System.out.println("e hai varias posibilidades, premendo TAB de novo, poderemos velas todas");
                    System.out.println("////////------------------////////////////////-------/////////////");
                    System.out.println("Historial de comandos" + "(history):");
                    System.out.println("Podemos movernos a través dos últimos 1000 comandos introducidos empregando os cursores");
                    System.out.println("////////------------------///////////////////-------///////////////");
                    System.out.println("Comando alias:Os alias permiten asociar nomes a comandos con determinadas opcións");

                    break;

                }

//////////////////////////////////////////   
///FORMA DE OBTENER AXUDA EN GNU/LINUX////    
//////////////////////////////////////////
                case "FORMAS*DE*AXUDA": {

                    System.out.println("Existen multiples formas de obter axuda dunha orde nun sistema Linux :");
                    System.out.println("#--help. : Moitos comandos posuen unha opcion para amosar unha axuda breve acerca do seu uso.");
                    System.out.println("ejemplo: mkdir --help");
                    System.out.println("#Info: info mkdir amosa algo de informacion sobre mkdir en este caso");
                    System.out.println("Whatis: Amosa unha axuda rápida dun comando");
                    System.out.println("ejemplo:whatis cp");
                    System.out.println("#man: manual bastante amplio acerca de comandos, formatos de ficheros de configuración");

                    break;
                }
///////////////////////////////////////////
//COMANDOS*PARA*DESCONECTARSE*DO*SISTEMA///
///////////////////////////////////////////

                case "COMANDOS*PARA*DESCONECTARSE*DO*SISTEMA": {

                    System.out.println("#exit");
                    System.out.println("Permite finalizar o Shell actual");
                    System.out.println("Se se ten un Shell único é equivalente a desconectarse do sistema");
                    System.out.println("pero se se están dentro dun subshell, só rematará este, retornando ao Shell anterior");

                    System.out.println("#logout");
                    System.out.println("Permite finalizar o Shell actual");
                    System.out.println("tamen Premendo Ctrl+D pecharase o terminal");

                    System.out.println("#poweroff");
                    System.out.println("Apaga o sistema");

                    System.out.println("#reboot");
                    System.out.println("Reinicia o equipo");

                    System.out.println("#shutdown");
                    System.out.println("*-*Permite apagar ou reiniciar o sistema");
                    System.out.println("*-*shutdown –h now Apaga el sistema (-halt) ahora (now)");
                    System.out.println("*-*shutdown -h 18:45 “Apagando o equipo para facer tarefas de mantemento");
                    System.out.println("*-*shutdown –r –g5 El sistema se reiniciará (-r) en 5 minutos (-g5)");

                    break;

                }
/////////////////////////////         
//ACTUALIZACION*DO*S.O//////
////////////////////////////                
                
                case "ACTUALIZACION*DO*S.O": {

                    System.out.println("#apt update");
                    System.out.println("ACTUALIZA A LISTAXE DE PAQUETES DISPOÑIBLES E AS SUAS VERSIONS ");
                    System.out.println("NON INSTALA NIN ACTUALIZA PAQUETES");

                    System.out.println("#apt upgrade");
                    System.out.println(" INSTALA NOVAS VERSIONS DOS PAQUETES QUE TEMOS");

                    System.out.println("#apt full-upgrade");
                    System.out.println(" COMO O ANTERIOR E ADEMAIS, DESINSTALA PAQUETE SE É NECESARIO");

                    System.out.println("#apt do-release-upgrade ");
                    System.out.println("PARA ACTUALIZAR A DISTRIBUCION A UNHA VERSION SUPERIOR");

                    break;
                }

                
                
                case "INSTALACION*DO*SISTEMA*OPERATIVO": {

                    System.out.println("#APT =>é un sistema de xestión de paquetes creado polo proxecto Debian.");

                    System.out.println("#apt install <nome-paquete1> <nome-paquete2> ");
                    System.out.println("INSTALACION DE PAQUETES");

                    System.out.println("#apt search <nome do paquete>");
                    System.out.println("BUSCA DUN PAQUETE ");

                    System.out.println("#apt show <nome-paquete>");
                    System.out.println("VER LA DESCRIPCION DE UN PAQUETE");

                    System.out.println("#apt list");
                    System.out.println("LISTA TODOS OS PAQUETES INSTALADOS ");

                    System.out.println("#apt remove <nome-paquete>");
                    System.out.println("ELIMINA UN PAQUETE");

                    System.out.println("#apt purge <nome-paquete>");
                    System.out.println("ELIMINA UN PAQUETE E ARQUIVOS DE CONFIGURACION");

                    System.out.println("#/etc/apt/sources.list ");
                    System.out.println("");

                    break;

                }
                case "ESTRUCTURA*DE*S.O": {

                    System.out.println("/bin");
                    System.out.println("contén os executables (binarios) esenciais para o sistema. Comandos máis básicos. ");

                    System.out.println("/boot");
                    System.out.println("aquí están os arquivos usados polo sistema durante o arranque, incluída a imaxe do núcleo");

                    System.out.println("/dev");
                    System.out.println("almacena os controladores (device drivers ou device files) para o acceso aos dispositivos físicos do disco, como o rato, as tarxetas, o escáner, etc. ");

                    System.out.println("/var");
                    System.out.println("adoita conter información variable, tanto xerada polo propio sistema como polos usuarios");

                    System.out.println("/lib");
                    System.out.println(", contén as librerías usadas por diferentes aplicacións, evitando que cada programa inclúa as súas propias coa conseguinte redundancia de ficheiros. ");

                    System.out.println("/etc");
                    System.out.println("é o directorio destinado para almacenar todos os arquivos de configuración do sistema. ");

                    System.out.println("/home");
                    System.out.println("contén a árbore de directorios propio de cada usuario do sistema.");
                    System.out.println("Atoparemos un subdirectorio para cada usuario, o que na contorna gráfico chámase Cartafol persoal");

                    System.out.println("/sbin");
                    System.out.println("aloxa comandos esenciais de administracion do sistema,, normalmente reservados ao administrador. ");

                    System.out.println("/usr");
                    System.out.println("onde se almacenan as aplicacións e recursos dispoñibles para todos os usuarios do sistema.");

                    System.out.println("/tmp");
                    System.out.println("é un directorio temporal usado generalmente polas aplicacións para almacenar algúns ficheros en tempo de ejecución");

                    System.out.println("/media");
                    System.out.println("cando montamos un CD-ROM, unha memoria USB ou un disquete créase aquí automáticamente un subdirectorio.");
                    System.out.println("/media/cdrom0, para a primeira unidade de CD-ROM. ");
                    System.out.println("/media/disk ,para os discos de memoria USB. ");

                    break;
                }
                case "COMANDOS*DE*XESTION*E*FLUXOVISUAL": {

                    System.out.println("#ls");
                    System.out.println("PERMITE LISTAR O CONTENIDO DE UN DIRECTORIO");
                    System.out.println(" SINTAXE ==>ls [opciones] [directorio | ficheiro]");
                    System.out.println("Algunhas opcións");
                    System.out.println("-l: amosa a salida en formato largo");
                    System.out.println("-R: lista recursivamente un directorio. ");
                    System.out.println("-a: lista os ficheiros incluidos os ocultos (os seus nomes comienzan con punto). ");
                    System.out.println("En linux considerase que un ficheiro ou directorio que comienza por punto é un arquivo oculto, e ls non o amosará a menos que o indiquemos");
                    System.out.println("-h: amosa o tamaño de los ficheros en forma máis lexible (Ej.: 16M, 4k, etc.) ");
                    System.out.println("-i: amosa o identificador do i-nodo (bloque índice) asociado a cada elemento.");
                    ////////////////////////////////////////////////////////////////////////////         
                    System.out.println("#cd");
                    System.out.println("Permite cambiar o directorio actual");
                    System.out.println("SINTAXE ==>cd [directorio]");
                    System.out.println("O comando cd ou cd ~ levanos directamente ó noso directorio home de usuario.");
                    System.out.println("Este directorio está situado normalmente en /home/nomedousuario para os usuarios normales y en /root para el usuario root.");
                    System.out.println("Non hai que confundir este directorio home do usuario co directorio /home del sistema.");
                    System.out.println("No caso dos usuarios normais é o único sitio de toda a árbore onde se poden crear ficheiros e directorios.");
                    System.out.println("Exemplos: cd /tmp, cd ~, \n");
///////////////////////////////////////////////////////////////////////////////	 
                    System.out.println("#pwd");
                    System.out.println("Indica o camino absoluto do directorio no cal nos atopamos actualment");

///////////////////////////////////////////////////////////////////                
                    System.out.println("# mkdir");
                    System.out.println("Crea directorios");
                    System.out.println("Sintaxe: mkdir [-opcion] directorio1 directorio2…");
                    System.out.println("Opcions:");
                    System.out.println("-p crea os directorios intermedios no caso de que non existan exemplo:==>Mkdir –p docs/linuxdocs/howtos/pdf");

//////////////////////////////////////////////////////////////////////////                
                    System.out.println("#mv");

                    System.out.println("Move varios arquivos a un directorio ou cambia o nome dun arquivo.");
                    System.out.println("Sintaxe==>mv [opciones] <orixe> <destino");
                    System.out.println("Sintaxe==>mv  <ficheiros> <directorio>");
                    System.out.println("Algunhas opcións:");
                    System.out.println("-i: executa o comando de forma interactiva, ou sexa, pregunta antes de sobrescribir o destino se existira.");
                    System.out.println("-u: actualiza (upgrade) o destino co orixe so se este é máis recente.");
///////////////////////////////////////////////////////////////////////////////////////

                    System.out.println("#cp");
                    System.out.println("Permite copiar un arquivo noutro ou varios arquivos nun directorio");
                    System.out.println("Sintax==>cp <orixe> [opciones]||<ficheiros> <destino> ");
                    System.out.println("opcións:");
                    System.out.println("-R: copia recursivamente un directorio. ");
                    System.out.println("-i: utiliza unha forma interactiva (pregunta antes de sobrescribir el destino).");
                    System.out.println("-l: crea enlaces ríxidos ós ficheiros fontes en lugar de cópialos.");

                    ////////////////////////////////////////////////////////////////////////////
                    System.out.println("rm");
                    System.out.println("O comando rm empregase para borrar arquivos e directorios");
                    System.out.println("SINTAXE ==> rm [opciones] <ficheiros | directorios>");

                    System.out.println("-r borra recursivamente un directorio");
                    System.out.println("-f borra forzosamente");
                    System.out.println("-i solicita confirmación");
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

                    System.out.println("#chown");
                    System.out.println("Cambia o dono e o grupo dun arquivo. ");
                    System.out.println("O dono dun arquivo só pode ser cambiado por root mentras que o grupo,");
                    System.out.println("ademáis do root, pode ser cambiado polo propio usuario sempre que pertenza a ese grupo");
                    System.out.println("sintaxe==> chown [opciones] dueño[.grupo]");
                    System.out.println("-R nos directorios, cambia o usuario e o grupo recursivamente");
///////////////////////////////////////////////////////////////////////////////////////////////

                    System.out.println("#chgrp");
                    System.out.println("Cambia o grupo dun arquivo");
                    System.out.println("SINTAXE==>chgrp [opciones] grupo ");
                    System.out.println("-R en los directorios, cambia el grupo recursivamente");

////////////////////////////////////////////////////                
                    System.out.println("#Cat");
                    System.out.println("O comando cat permite concatenar (conCATenate) ficheiros, é decir, coller varios ficheiros de texto e unilos nun só.");
                    System.out.println("Por defecto cat manda os arquivos á saida estándar del sistema (stdout) que é apantalla, polo que normalmente utilizamos esta orden para visualizar ");
                    System.out.println("SINTAXE==> Sintaxe: cat [opciones]");
///////////////////////////////////////////////////////////////////////////                
                    System.out.println("#less");
                    System.out.println("Paxina un arquivo (dividen en páxinas) ou varios e amosan na pantalla o seu contido");
                    System.out.println("less /etc/passwd ");
///////////////////////////////////////////////////////////////////////////////////////                
                    System.out.println("#more");
                    System.out.println("Paxina un arquivo é restrictivo en canto o movemento dentro do texto");
                    System.out.println("se alcanza o fin do último arquivo a paxinar, more remata automanticamente");
                    System.out.println("more /etc/passwd");
/////////////////////////////////////////////////////////////////////////////////////////////

                    System.out.println("#man");
                    System.out.println("man, para dar formato a súa saída, utiliza por defecto o visualizador less");
///////////////////////////////////////////////////////////////////////////////////////////////////////////

                    break;

                }
                case "REDIRECCIONAMIENTO": {

                    System.out.println("# > ");
                    System.out.println("dirixe o resultado da execución dun comando directamente a un dispositivo ou ficheiro especificado. ");
                    System.out.println("Créase se non existe e sobreescríbese se xa existe. \n¡Por exemplo: 	ls > listado.txt");
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                    System.out.println("#<");
                    System.out.println("toma os datos de entrada desde o ficheiro ou dispositivo que se lle especifique");
////////////////////////////////////////////////                

                    System.out.println("#>>");
                    System.out.println("dirixe o resultado da execución dun comando a un ficheiro. ");
                    System.out.println("souçSe existe o ficheiro destino, o resultado da execución engádese ao final sen perder a información que había en dito ficheiro. Se non existe, créase.");
///////////////////////////////////////////////////////////////////////////////////////////////////
                    break;

                }
                case "TUBERIA": {

                    System.out.println("# | ");
                    System.out.println("A tubería ou pipe (|) permite tomar a saída dun comando e facer que sexa a entrada doutro");
                    System.out.println("As tuberías separan comandos");
                    System.out.println("As distintas ordes executanse secuencialmente");
                    /////////////////////////////////////////////////////////////////////////////  

                }
                case "COMPARACION*E*AGRUPACION*DE*ARQUIVOS": {

                    System.out.println("# gzip y gunzip");
                    System.out.println("permiten compactar e descompactar (comprimir e descomprimir) ");
                    System.out.println("respectivamente un ou varios arquivos");
                    System.out.println("SINTAXE==>gzip [opcions] <ficheiros/directorio>");
                    System.out.println("SINTAXE==>gunzip [opcions] <ficheiros/directorio>");
                    System.out.println("");
                    System.out.println("OPCIONS");
                    System.out.println("-r: dado un directorio comprime todos los ficheros presentes en él recursivamente.");
                    System.out.println("-1 a -9: especifica el grado de la compresión (-1 menor y más rápida -9 mayor y más lenta). ");
                    System.out.println("-S : permite especificar un sufijo o extensión para el fichero resultado (por defecto es gz).");
/////////////////////////////////////////////////////////////////////////////////////              
                    System.out.println("#tar");
                    System.out.println("*-*tar (Tape Archiver) é unha ferramenta para agrupar ficheiros aillados ou o contido dun directorio noutro ficheiro");
                    System.out.println(" ou dispositivo especial. ");
                    System.out.println("*-*tar non comprime ou compacta nada, limitase a agrupar varios arquivos nun só, sen comprimilos");
                    System.out.println("*-*Existe unha opción –z que executa automáticamente gzip/gzip sobre o arquivo agrupado");
                    System.out.println("SINTAXE==> Tar [opcions] <orixe>");
                    System.out.println("O comando tar conseva a estrutura xerarquica dos arquivos e directorios agrupados excluindo o carácter /.");

                    /////////////////////////////////////////////////////////
                    System.out.println("OPCIONS:*---*---*");
                    System.out.println("-c, permite crear");
                    System.out.println("-x, permite extraer");
                    System.out.println("-f ficheiro, agrupa ou desagrupa en/hacia un arquivo");
                    System.out.println("-z, compacta ou descompacta o arquivo resultante");
                    System.out.println("-t, lista o contido dun arquivo dun agrupamento");
                    System.out.println("-M, agrupa en volúmenes");

                }
            }
        } while (!COMANDOG.equalsIgnoreCase("EXIT"));

    }
}

// } while (!COMANDOG.equalsIgnoreCase("EXIT"));
//                System.out.println("");
//                System.out.println("");
//                System.out.println("");
//                System.out.println("");
//                System.out.println("");
//                System.out.println("");
//                System.out.println("");
//                System.out.println("");
//                System.out.println("");
//                System.out.println("");
//                System.out.println("");
//                System.out.println("");
//                System.out.println("");
//                System.out.println("");
//                System.out.println("");
//                System.out.println("");
//                System.out.println("");
//                System.out.println("");
//                System.out.println("");
//                System.out.println("");
//      while (!COMANDOG.equalsIgnoreCase("EXIT"));
//}

